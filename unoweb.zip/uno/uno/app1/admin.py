from django.contrib import admin
from .models import Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, Expenses, Inventory, Training, Workexperience, Education, Docs, Addnewbank, Bankdetails, Leaveapplication     
from .forms import ProjectsForm, GroupsForm, AddnewemployeeForm, EmployeeForm, AddnewdepartmentForm, CostcenterForm, ExpensesForm, InventoryForm, TrainingForm, WorkexperienceForm, EducationForm, DocsForm, AddnewbankForm, BankdetailsForm, LeaveapplicationForm 

# Define the EmployeeAdmin class
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'department', 'email')  # Customize this as needed
    form = EmployeeForm  # Use the custom form

# Register the Employee model with the EmployeeAdmin class
admin.site.register(Employee, EmployeeAdmin)

# Define the ProjectsAdmin class
class ProjectsAdmin(admin.ModelAdmin):
    list_display = (
        'project_id', 'photograph', 'project_name', 'department', 'group', 'employee', 'shift', 'supervisor',
        'description', 'public_holiday', 'rest_day'
    )
    form = ProjectsForm  # Use the custom form

# Register the Projects model with the ProjectsAdmin class
admin.site.register(Projects, ProjectsAdmin)

class WorkexperienceAdmin(admin.ModelAdmin):
    list_display = ('designation','department','from_date','to_date','employment_type','salary',
        'attachment_doc','remarks','company_name','designations','date_of_joining','date_of_leaving'
     )
    form =WorkexperienceForm
admin.site.register(Workexperience, WorkexperienceAdmin) 

class EducationAdmin(admin.ModelAdmin):
    list_display = ('qualification','institute','type','start_date','end_date','description'
        
     )
    form =EducationForm
admin.site.register(Education, EducationAdmin) 


class DocsAdmin(admin.ModelAdmin):
    list_display = ('type_name','attachments','id','date_of_issue','date_of_expiry'
        
     )
    form =DocsForm
admin.site.register(Docs, DocsAdmin) 


class CostcenterAdmin(admin.ModelAdmin):
    list_display = (
        'costcenter', 'description', 'percentage'
    )
    form = CostcenterForm 

admin.site.register(Costcenter, CostcenterAdmin)

class AddnewbankAdmin(admin.ModelAdmin):
    list_display = (
        'bank_name','branch_code','bank_acc_number','account_name','organization_id'
    )
    form = AddnewbankForm 

admin.site.register(Addnewbank, AddnewbankAdmin)

class BankdetailsAdmin(admin.ModelAdmin):
    list_display = (
        'payment_mode','employee_bank','bank_code','account_no','bank_branch_code','bank_b1',
        'bank','bank_info_details',
        'check_banked','chip_level_bank','covid_vaccine','discovery'
    )
    form = BankdetailsForm 

admin.site.register(Bankdetails, BankdetailsAdmin)

class InventoryAdmin(admin.ModelAdmin):
    list_display = (
        'item_name', 'quantity', 'file_attachment', 'description', 'date_of_issue', 'date_of_collection'
    )
    form = InventoryForm  

admin.site.register(Inventory, InventoryAdmin)

class TrainingAdmin(admin.ModelAdmin):
    list_display = (
        'certification', 'grade', 'file_attachment', 'effective_date', 'projected_date', 'status'
    )
    form = TrainingForm  

admin.site.register(Training, TrainingAdmin)


class ExpensesAdmin(admin.ModelAdmin):
    list_display = (
        'amount', 'issued_date', 'description'
    )
    form = ExpensesForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Expenses, ExpensesAdmin)


# Define the GroupsAdmin class
class GroupsAdmin(admin.ModelAdmin):
    list_display = (
        'group_id', 'photograph', 'group_name', 'department', 'projects', 'employees'
    )
    form = GroupsForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Groups, GroupsAdmin)

class LeaveapplicationAdmin(admin.ModelAdmin):
    list_display = (
        'employee','leave_type', 'from_date', 'to_date', 'sessions','no_of_days_applying','remarks','upload_document'
    )
    form = LeaveapplicationForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Leaveapplication, LeaveapplicationAdmin)



class AddnewdepartmentAdmin(admin.ModelAdmin):
    list_display = ('photograph', 'department_name', 'get_employees')  # Use custom method

    def get_employees(self, obj):
        return ", ".join([employee.name for employee in obj.employees.all()])  # Adjust this line based on your Employee model
    get_employees.short_description = 'Employees'

admin.site.register(Addnewdepartment, AddnewdepartmentAdmin)



class AddnewemployeeAdmin(admin.ModelAdmin):
    list_display = (
        'first_name', 'last_name', 'alias_name', 'preferred_name', 'gender', 'marital_status', 
        'date_of_birth', 'nationality', 'religion', 'race', 'blood_group', 'place_of_birth', 
        'identification_type', 'ic_no', 'block_number', 'house_number', 'street_number', 
        'country', 'postal_code', 'mobile_number', 'emergency_contact_person', 'relationship', 
        'emergency_contact', 'overseas_address', 'personal_email_address', 'photograph', 'email', 
        'user_security', 'custom_field_add', 'email_outlook_access', 'first_name_for_email_creation', 
        'last_name_for_email_creation', 'may_day', 'name_of_vaccine_1st_dose', 'new_year_event', 
        'physical_last_day', 'physical_last_working_day', 'sports', 'surname', 'test_s', 'employee_id', 
        'joining_date', 'employment_type', 'probation_period', 'confirmation_date', 'departments', 
        'designation', 'groups', 'supervisor_name', 'appraisal_supervisor1', 'appraisal_supervisor2', 
        'academic_qualification', 'skill_set', 'working_hours_per_month', 'working_hours_per_day', 
        'working_days_per_week', 'no_of_work_days_per_week', 'working_hours_per_day_breakdown', 
        'payroll_frequency', 'salary_type', 'basic_pay', 'payslip_language', 'leave_workflow', 
        'leave_code', 'leave_type_entitlement', 'claim_workflow', 'claim_types', 
        'length_of_notice_period', 'cpf_entitled', 'cpf_file_type', 'contribute_sdl', 
        'sdl_breakdown', 'fund_donation', 'clock_in_out_on_web', 'clock_in_out_on_mobile', 
        'remarks', 'job_grade', 'pin_number', 'geofencing_postal_code', 'abc', 'custom_field1', 
        'dd', 'email_for_supervisor', 'family_relationship', 'job_type', 'job_type_list', 
        'job_type1', 'job_type2', 'job_type3', 'sample', 'service_date_dd_mm_yyyy', 'testing_1'
    )
    form = AddnewemployeeForm  # Use the custom form

# Register the Addnewemployee model with the AddnewemployeeAdmin class
admin.site.register(Addnewemployee, AddnewemployeeAdmin)
