from django.db import models
from django.core.exceptions import ValidationError



class Leaveapplication(models.Model):
    employee = models.CharField(max_length=255)
    leave_type = models.CharField(max_length=255)
    from_date = models.DateField()
    to_date = models.DateField()
    sessions = models.CharField(max_length=255)  # Adjust the max_length according to your needs
    no_of_days_applying = models.PositiveIntegerField()
    remarks = models.TextField(blank=True, null=True)
    upload_document = models.FileField(upload_to='documents/', blank=True, null=True)

    def __str__(self):
        return f"{self.employee} - {self.leave_type} ({self.from_date} to {self.to_date})"

class Addnewbank(models.Model):
   
    bank_name = models.CharField(max_length=100)
    branch_code = models.CharField(max_length=50)
    bank_acc_number = models.CharField(max_length=50)
    account_name = models.CharField(max_length=100)
    organization_id = models.IntegerField()

    def __str__(self):
        return f"{self.bank_name} - {self.account_name}"

class Bankdetails(models.Model):
    PAYMENT_MODE_CHOICES = [
        ('cash', 'Cash'),
        ('cheque', 'Cheque'),
        ('online', 'Online'),
        ('adnewbank', 'Add New Bank'),
    ]

    DISCOVERY_CHOICES = [
        ('cash_and_delivery', 'Cash and Delivery'),
        ('shipping', 'Shipping'),
        ('skyline', 'Skyline'),
        ('animal_plant', 'Animal Plant'),
    ]

    payment_mode = models.CharField(max_length=20, choices=PAYMENT_MODE_CHOICES)
    employee_bank = models.CharField(max_length=100)
    bank_code = models.CharField(max_length=50)
    account_no = models.CharField(max_length=50)
    bank_branch_code = models.CharField(max_length=50)
    bank_b1 = models.CharField(max_length=50)
    bank = models.CharField(max_length=100)
    bank_info_details = models.TextField()
    check_banked = models.BooleanField(default=False)
    chip_level_bank = models.CharField(max_length=100)
    covid_vaccine = models.BooleanField(default=False)
    discovery = models.CharField(max_length=50, choices=DISCOVERY_CHOICES)

    def __str__(self):
        return f"{self.employee_bank} - {self.bank}"

class Education(models.Model):
    FULL_TIME = 'FT'
    PART_TIME = 'PT'
    TYPE_CHOICES = [
        (FULL_TIME, 'Full Time'),
        (PART_TIME, 'Part Time'),
    ]

    qualification = models.CharField(max_length=255)
    institute = models.CharField(max_length=255)
    type = models.CharField(
        max_length=2, 
        choices=TYPE_CHOICES, 
        default=FULL_TIME,
        verbose_name="Type of Education"
    )
    start_date = models.DateField()
    end_date = models.DateField()
    description = models.TextField(blank=True, null=True)

    def clean(self):
        # Ensure that start_date is before end_date
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValidationError("Start date cannot be after end date.")

    def __str__(self):
        return f"{self.qualification} at {self.institute}"

    class Meta:
        verbose_name = "Education"
        verbose_name_plural = "Education Details"

class Docs(models.Model):
    TYPE_CHOICES = [
        ('passport', 'Passport'),
        ('visa', 'Visa'),
        ('id_card', 'ID Card'),
        # Add more document types as needed
    ]
    
    type_name = models.CharField(max_length=100, choices=TYPE_CHOICES)
    attachments = models.FileField(upload_to='documents/')
    date_of_issue = models.DateField()
    date_of_expiry = models.DateField()
    
    def __str__(self):
        return f"{self.get_type_name_display()} - {self.id}"


class Workexperience(models.Model):
    designation = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    from_date = models.DateField()
    to_date = models.DateField()
    employment_type = models.CharField(max_length=50)  # e.g., Full-time, Part-time, etc.
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    attachment_doc = models.FileField(upload_to='attachments/')
    remarks = models.TextField(blank=True, null=True)
    company_name = models.CharField(max_length=255)
    designations = models.CharField(max_length=255)  # If this is meant to be different from 'designation'
    date_of_joining = models.DateField()
    date_of_leaving = models.DateField()

    def __str__(self):
        return f"{self.designation} at {self.company_name}"

class Training(models.Model):
    CERTIFICATION_CHOICES = [
        ('Cert1', 'Certification 1'),
        ('Cert2', 'Certification 2'),
        ('Cert3', 'Certification 3'),
        # Add more certifications as needed
    ]

    GRADE_CHOICES = [
        ('A', 'Grade A'),
        ('B', 'Grade B'),
        ('C', 'Grade C'),
        # Add more grades as needed
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approval', 'Approval'),
    ]

    certification = models.CharField(max_length=50, choices=CERTIFICATION_CHOICES)
    grade = models.CharField(max_length=2, choices=GRADE_CHOICES)
    file_attachment = models.FileField(upload_to='training_files/')
    effective_date = models.DateField()
    projected_date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    def __str__(self):
        return f'{self.certification} - {self.grade}'




class Expenses(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)  # Amount field with two decimal places
    issued_date = models.DateField()  # Date when the expense was issued
    description = models.TextField()  # Description of the expense
   

    def __str__(self):
        return f"Expense of {self.amount} on {self.issued_date}"

class Inventory(models.Model):
    item_name = models.CharField(max_length=255)
    quantity = models.IntegerField()
    file_attachment = models.FileField(upload_to='attachments/', blank=True, null=True)
    description = models.TextField()
    date_of_issue = models.DateField()
    date_of_collection = models.DateField()

    def __str__(self):
        return self.item_name

class Costcenter(models.Model):
    COST_CENTER_CHOICES = [
        ('DEMO', 'Demo Cost Center, Testing-dc_123'),
        ('HR', 'Human Resources-HRs'),
        ('PA', 'Projects A'),
        ('PB', 'Projects B'),
        ('PC', 'Projects C'),
    ]
    
    costcenter = models.CharField(
        max_length=5,  # Adjusted to match the length of the choices ('DEMO', 'HR', etc.)
        choices=COST_CENTER_CHOICES
    )
    description = models.TextField(
        blank=True, 
        null=True
    )  # Optional: Additional description
    percentage = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True, 
        help_text="Percentage value (e.g., 20.50 for 20.50%)"
    )

    def __str__(self):
        return f"{self.get_costcenter_display()} - {self.percentage}%"

# Define your PostalCode model here if it doesn't already exist
class Addnewdepartment(models.Model):
    photograph = models.ImageField(upload_to='photographs/', null=True, blank=True)
    department_name = models.CharField(max_length=100)
    get_employees = models.ManyToManyField('Employee')  # Example field

    def __str__(self):
        return self.department_name


class Projects(models.Model):
    project_id = models.CharField(max_length=10, unique=True)  # Custom ID field
    photograph = models.ImageField(upload_to='photographs/', null=True, blank=True)
    project_name = models.CharField(max_length=100)  # Field to store the project name

    DEPARTMENT_CHOICES = [
        ('HR', 'Human Resources'),
        ('IT', 'Information Technology'),
        ('Finance', 'Finance'),
        ('Marketing', 'Marketing'),
        ('Sales', 'Sales'),
        ('Operations', 'Operations'),
        ('Customer Service', 'Customer Service'),
        ('Legal', 'Legal'),
        ('R&D', 'Research and Development'),
        ('Admin', 'Administration'),
    ]
    department = models.CharField(max_length=100, choices=DEPARTMENT_CHOICES)  # Department choices

    GROUP_CHOICES = [
        ('Tester', 'A'),
        ('B', 'Developer'),
        ('C', 'Manager'),
        ('D', 'Teamlead'),
        ('E', 'Employee'),
        ('F', 'Fresher'),
        ('G', 'Experienced'),
        ('H', 'Python'),
        ('I', 'Java'),
        ('J', 'Web Developing'),
    ]
    group = models.CharField(max_length=100, choices=GROUP_CHOICES)  # Group choices

    EMPLOYEE_CHOICES = [
        ('John Doe', 'John Doe'),
        ('Jane Smith', 'Jane Smith'),
        ('Alice Johnson', 'Alice Johnson'),
        ('Bob Brown', 'Bob Brown'),
        ('Charlie Davis', 'Charlie Davis'),
        ('Diana Evans', 'Diana Evans'),
        ('Frank Green', 'Frank Green'),
        ('Grace Harris', 'Grace Harris'),
        ('Henry Ives', 'Henry Ives'),
        ('Ivy Jones', 'Ivy Jones'),
    ]
    employee = models.CharField(max_length=100, choices=EMPLOYEE_CHOICES)  # Employee choices

    SHIFT_CHOICES = [
        ('Morning', 'Morning Shift'),
        ('Afternoon', 'Afternoon Shift'),
        ('Night', 'Night Shift'),
        ('Weekend', 'Weekend Shift'),
        ('Flexible', 'Flexible Shift'),
    ]
    shift = models.CharField(max_length=100, choices=SHIFT_CHOICES)  # Shift choices

    SUPERVISOR_CHOICES = [
        ('John Smith', 'John Smith'),
        ('Emily Johnson', 'Emily Johnson'),
        ('Michael Brown', 'Michael Brown'),
        ('Sarah Davis', 'Sarah Davis'),
        ('David Wilson', 'David Wilson'),
        ('Laura Moore', 'Laura Moore'),
        ('James Taylor', 'James Taylor'),
        ('Linda Anderson', 'Linda Anderson'),
        ('Robert Thomas', 'Robert Thomas'),
        ('Karen White', 'Karen White'),
    ]
    supervisor = models.CharField(max_length=100, choices=SUPERVISOR_CHOICES)  # Supervisor choices

   
    description = models.TextField(blank=True, null=True)  # Optional: Additional description

    PUBLIC_HOLIDAY_CHOICES = [
        ('Yes', 'Yes'),
        ('No', 'No'),
    ]
    public_holiday = models.CharField(max_length=5, choices=PUBLIC_HOLIDAY_CHOICES)  # Public holiday choices

    REST_DAY_CHOICES = [
        ('Yes', 'Yes'),
        ('No', 'No'),
    ]
    rest_day = models.CharField(max_length=5, choices=REST_DAY_CHOICES)  # Rest day choices

    def __str__(self):
        return self.project_name


class Groups(models.Model):

    group_id = models.CharField(max_length=10, unique=True)  # Custom ID field
    photograph = models.ImageField(upload_to='photographs/', null=True, blank=True)
    group_name = models.CharField(max_length=100)  # Field to store the project name

    DEPARTMENT_CHOICES = [
        ('HR', 'Human Resources'),
        ('IT', 'Information Technology'),
        ('Finance', 'Finance'),
        ('Marketing', 'Marketing'),
        ('Sales', 'Sales'),
        ('Operations', 'Operations'),
        ('Customer Service', 'Customer Service'),
        ('Legal', 'Legal'),
        ('R&D', 'Research and Development'),
        ('Admin', 'Administration'),
    ]
    department = models.CharField(max_length=100, choices=DEPARTMENT_CHOICES)  # Department choices

    PROJECTS_CHOICES = [
        ('HR', 'Human Resources'),
        ('IT', 'Information Technology'),
        ('Finance', 'Finance'),
        ('Marketing', 'Marketing'),
        ('Sales', 'Sales'),
        ('Operations', 'Operations'),
        ('Customer Service', 'Customer Service'),
        ('Legal', 'Legal'),
        ('R&D', 'Research and Development'),
        ('Admin', 'Administration'),
    ]
    projects = models.CharField(max_length=100, choices=PROJECTS_CHOICES)  # Projects choices

    EMPLOYEES_CHOICES = [
        ('John Doe', 'John Doe'),
        ('Jane Smith', 'Jane Smith'),
        ('Alice Johnson', 'Alice Johnson'),
        ('Bob Brown', 'Bob Brown'),
        ('Charlie Davis', 'Charlie Davis'),
        ('Diana Evans', 'Diana Evans'),
        ('Frank Green', 'Frank Green'),
        ('Grace Harris', 'Grace Harris'),
        ('Henry Ives', 'Henry Ives'),
        ('Ivy Jones', 'Ivy Jones'),
    ]
    employees = models.CharField(max_length=100, choices=EMPLOYEES_CHOICES)  # Employee choices

    def __str__(self):
        return self.group_name




class Addnewemployee(models.Model):

    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    alias_name = models.CharField(max_length=100, blank=True, null=True)
    preferred_name = models.CharField(max_length=100, blank=True, null=True)
    
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    
    MARITAL_STATUS_CHOICES = [
        ('Single', 'Single'),
        ('Married', 'Married'),
        ('Divorced', 'Divorced'),
        ('Widowed', 'Widowed'),
    ]
    marital_status = models.CharField(max_length=10, choices=MARITAL_STATUS_CHOICES)
    
    date_of_birth = models.DateField()
    nationality = models.CharField(max_length=100)
    religion = models.CharField(max_length=100, blank=True, null=True)
    race = models.CharField(max_length=100, blank=True, null=True)
    blood_group = models.CharField(max_length=3, blank=True, null=True)
    place_of_birth = models.CharField(max_length=100, blank=True, null=True)
    
    identification_type = models.CharField(max_length=50)
    ic_no = models.CharField(max_length=20, unique=True)
    
    block_number = models.CharField(max_length=10, blank=True, null=True)
    house_number = models.CharField(max_length=10, blank=True, null=True)
    street_number = models.CharField(max_length=100)
    
    country = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    
    mobile_number = models.CharField(max_length=15)
    emergency_contact_person = models.CharField(max_length=100)
    relationship = models.CharField(max_length=50)
    emergency_contact = models.CharField(max_length=15)
    
    overseas_address = models.TextField(blank=True, null=True)
    personal_email_address = models.EmailField()
    photograph = models.ImageField(upload_to='employee_photographs/', null=True, blank=True)
    
    email = models.EmailField(unique=True)
    user_security = models.CharField(max_length=100, blank=True, null=True)
    
    custom_field_add = models.CharField(max_length=100, blank=True, null=True)
    email_outlook_access = models.BooleanField(default=False)
    
    first_name_for_email_creation = models.CharField(max_length=100, blank=True, null=True)
    last_name_for_email_creation = models.CharField(max_length=100, blank=True, null=True)
    
    may_day = models.DateField(blank=True, null=True)
    name_of_vaccine_1st_dose = models.CharField(max_length=100, blank=True, null=True)
    new_year_event = models.CharField(max_length=100, blank=True, null=True)
    
    physical_last_day = models.DateField(blank=True, null=True)
    physical_last_working_day = models.DateField(blank=True, null=True)
    
    sports = models.CharField(max_length=100, blank=True, null=True)
    surname = models.CharField(max_length=100)
    test_s = models.CharField(max_length=100, blank=True, null=True)
    
    employee_id = models.IntegerField(default=0)

    joining_date = models.DateField()
    employment_type = models.CharField(max_length=100)
    probation_period = models.IntegerField()
    confirmation_date = models.DateField(blank=True, null=True)
    
    departments = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    groups = models.CharField(max_length=100)
    
    supervisor_name = models.CharField(max_length=100)
    appraisal_supervisor1 = models.CharField(max_length=100, blank=True, null=True)
    appraisal_supervisor2 = models.CharField(max_length=100, blank=True, null=True)
    
    academic_qualification = models.CharField(max_length=100)
    skill_set = models.CharField(max_length=100)
    
    working_hours_per_month = models.IntegerField()
    working_hours_per_day = models.IntegerField()
    working_days_per_week = models.IntegerField()
    
    no_of_work_days_per_week = models.IntegerField()
    working_hours_per_day_breakdown = models.CharField(max_length=100, blank=True, null=True)
    
    payroll_frequency = models.CharField(max_length=100)
    salary_type = models.CharField(max_length=100)
    basic_pay = models.DecimalField(max_digits=10, decimal_places=2)
    
    payslip_language = models.CharField(max_length=50)
    leave_workflow = models.CharField(max_length=100, blank=True, null=True)
    leave_code = models.CharField(max_length=50, blank=True, null=True)
    leave_type_entitlement = models.CharField(max_length=100, blank=True, null=True)
    
    claim_workflow = models.CharField(max_length=100, blank=True, null=True)
    claim_types = models.CharField(max_length=100, blank=True, null=True)
    
    length_of_notice_period = models.CharField(max_length=100)
    cpf_entitled = models.BooleanField(default=False)
    cpf_file_type = models.CharField(max_length=100, blank=True, null=True)
    
    contribute_sdl = models.BooleanField(default=False)
    sdl_breakdown = models.CharField(max_length=100, blank=True, null=True)
    
    fund_donation = models.CharField(max_length=100, blank=True, null=True)
    clock_in_out_on_web = models.BooleanField(default=False)
    clock_in_out_on_mobile = models.BooleanField(default=False)
    
    remarks = models.TextField(blank=True, null=True)
    job_grade = models.CharField(max_length=100)
    
    pin_number = models.CharField(max_length=10, unique=True)
    geofencing_postal_code = models.CharField(max_length=20, blank=True, null=True)
    
    abc = models.CharField(max_length=100, blank=True, null=True)
    custom_field1 = models.CharField(max_length=100, blank=True, null=True)
    dd = models.CharField(max_length=100, blank=True, null=True)
    
    email_for_supervisor = models.EmailField(blank=True, null=True)
    family_relationship = models.CharField(max_length=100, blank=True, null=True)
    
    job_type = models.CharField(max_length=100)
    job_type_list = models.CharField(max_length=100, blank=True, null=True)
    job_type1 = models.CharField(max_length=100, blank=True, null=True)
    job_type2 = models.CharField(max_length=100, blank=True, null=True)
    job_type3 = models.CharField(max_length=100, blank=True, null=True)
    
    sample = models.CharField(max_length=100, blank=True, null=True)
    service_date_dd_mm_yyyy = models.DateField(blank=True, null=True)
    testing_1 = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
   
class Employee(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    department = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


