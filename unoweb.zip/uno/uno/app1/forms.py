from django import forms
from django.contrib.auth.models import User
from .models import Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, Expenses, Inventory, Training, Workexperience, Education, Docs, Addnewbank, Bankdetails, Leaveapplication

class SignUpForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'first_name', 'last_name']

class ProjectsForm(forms.ModelForm):
    class Meta:
        model = Projects
        fields = ['project_id', 'photograph', 'project_name', 'department', 'group', 'employee', 'shift', 'supervisor',
                  'description', 'public_holiday', 'rest_day']

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee  # Assuming you have an Employee model
        fields = '__all__'
        widgets = {
            'field_name': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'another_field': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            # Add similar entries for other fields
        }

class GroupsForm(forms.ModelForm):
    class Meta:
        model = Groups
        fields = ['group_id', 'photograph', 'group_name', 'department', 'projects', 'employees']

class AddnewemployeeForm(forms.ModelForm):
    class Meta:
        model = Addnewemployee
        fields = '__all__'

class AddnewdepartmentForm(forms.ModelForm):
    class Meta:
        model = Addnewdepartment
        fields = '__all__'

class CostcenterForm(forms.ModelForm):
    class Meta:
        model = Costcenter
        fields = '__all__'


class ExpensesForm(forms.ModelForm):
    class Meta:
        model = Expenses
        fields = '__all__'

class InventoryForm(forms.ModelForm):
    class Meta:
        model = Inventory
        fields = '__all__'

class TrainingForm(forms.ModelForm):
    class Meta:
        model = Training
        fields = '__all__'

class WorkexperienceForm(forms.ModelForm):
    class Meta:
        model = Workexperience
        fields = '__all__'


class EducationForm(forms.ModelForm):
    class Meta:
        model = Education
        fields = '__all__'



class DocsForm(forms.ModelForm):
    class Meta:
        model = Docs
        fields = '__all__'


class AddnewbankForm(forms.ModelForm):
    class Meta:
        model = Addnewbank
        fields = '__all__'

class BankdetailsForm(forms.ModelForm):
    class Meta:
        model = Bankdetails
        fields = '__all__'


class LeaveapplicationForm(forms.ModelForm):
    class Meta:
        model = Leaveapplication
        fields = '__all__'




