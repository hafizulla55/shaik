from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from app1.forms import SignUpForm, ProjectsForm, GroupsForm, AddnewemployeeForm ,EmployeeForm, AddnewdepartmentForm, CostcenterForm, ExpensesForm, InventoryForm, TrainingForm, WorkexperienceForm, EducationForm, DocsForm, BankdetailsForm, AddnewbankForm, LeaveapplicationForm# Removed AddemployeegroupsForm
from .models import Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, Expenses, Inventory, Training, Workexperience, Education, Docs, Bankdetails, Addnewbank, Leaveapplication
from django.http import HttpResponseRedirect


def announcement_view(request):
    return render(request, 'announcement.html')
@login_required
def departmentsview(request):
    Add = Addnewdepartment.objects.all() 
    return render(request, 'app1/departments.html',{'f':Add})


def handbook_view(request):
    # Your view logic here
    return render(request, 'handbook.html')
@login_required
def addnewdepartmentview(request):
    if request.method == 'POST':
        form = AddnewdepartmentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/departments')
    else:
        form = AddnewdepartmentForm()
    return render(request, 'app1/addnewdepartment.html', {'form': form})


@login_required
def addnewemployeeview(request):
    if request.method == 'POST':
        form = AddnewemployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewemployeeForm()
    return render(request, 'app1/addnewemployee.html', {'form': form})



def employeeview(request):
    form = EmployeeForm()  # Assuming 'EmployeeForm' is your form class
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, 'app1/employee.html', {'form': form})
    

@login_required
def onboardingview(request):
    employees = Addnewemployee.objects.all()  # Retrieve all employees from the database
    return render(request, 'app1/onboarding.html', {'employees': employees})
@login_required
def expensesview(request):
    if request.method == 'POST':
        form = ExpensesForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = ExpensesForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/expenses.html', {'form': form})

@login_required
def inventoryview(request):
    if request.method == 'POST':
        form = InventoryForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = InventoryForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/inventory.html', {'form': form})


@login_required
def workexperienceview(request):
    if request.method == 'POST':
        form = WorkexperienceForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = WorkexperienceForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/workexperience.html', {'form': form})

@login_required
def educationview(request):
    if request.method == 'POST':
        form = EducationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = EducationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/education.html', {'form': form})

@login_required
def docsview(request):
    if request.method == 'POST':
        form = DocsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = DocsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/Docs.html', {'form': form})

@login_required
def addnewbankview(request):
    if request.method == 'POST':
        form = AddnewbankForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewbankForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/Addnewbank.html', {'form': form})

@login_required
def bankdetailsview(request):
    if request.method == 'POST':
        form = BankdetailsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = BankdetailsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/Bankdetails.html', {'form': form})

@login_required
def trainingview(request):
    if request.method == 'POST':
        form = TrainingForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = TrainingForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/training.html', {'form': form})

def language_change(request, language_code):
    # Logic to change the language
    return redirect('home')  # Redirect or render appropriate response
def searchview(request):
    # Your logic here
    return render(request, 'app1/search.html')
@login_required
def guide_view(request):
    return render(request, 'app1/guide.html')
@login_required
def faqs_view(request):
    return render(request, 'app1/faqs.html')
@login_required
def support_view(request):
    return render(request, 'app1/support.html')
@login_required
def audit_logs_view(request):
    return render(request, 'app1/audit_logs.html')

@login_required
def leaveview(request):
    leaveapplication = Leaveapplication.objects.all()
   
    return render(request, 'app1/leave.html', {'leave': leaveapplication})

@login_required
def claimview(request):
    return render(request, 'app1/claim.html')
def claim_view(request):
    return render(request, 'claim.html')
def reports_view(request):
    return render(request, 'reports.html')
def timesheetmanagementview(request):
    return render(request, 'app1/timesheetmanagement.html')
def scheduling_view(request):
    return render(request, 'scheduling.html')
def payrollview(request):
    return render(request, 'app1/payroll.html')
def leave_view(request):
    # Your view logic here
    return render(request, 'leave.html')

def elearningview(request):
    return render(request, 'app1/elearning.html')

def self_service_view(request):
    return render(request, 'self_service.html')
def gmail(request):
    # Your logic here
    return render(request, 'gmail.html')
def appraisal_view(request):
    return render(request, 'appraisal.html')
def recruitment_view(request):
    return render(request, 'recruitment.html')


@login_required    
def settingsview(request):
    return render(request, 'app1/settings.html')



def switch_company(request):
    return render(request, 'switch_company.html')
def notifications(request):
    # Your logic here
    return render(request, 'notifications.html')
def expenses_view(request):
    return render(request, 'expenses.html')
def feedbackview(request):
    return render(request, 'app1/feedback.html')
def polling_view(request):
    return render(request, 'polling.html')

@login_required
def securityview(request):
    return render(request, 'app1/security.html')


@login_required
def announcement_view(request):
    return render(request, 'app1/announcement.html')
@login_required
def handbook_view(request):
    return render(request, 'app1/handbook.html')
@login_required
def enhancements_view(request):
    return render(request, 'app1/enhancements.html')

@login_required
def homeview(request):
    return render(request, 'app1/home.html')


@login_required
def expenses_viewview(request):
    return render(request, 'app1/expenses_view.html')

@login_required
def dashboardview(request):
    projects = Projects.objects.all()  # Replace with your actual model
    groups = Groups.objects.all()  # Replace with your actual model
    hafi = Addnewemployee.objects.all() 
    dee =Inventory.objects.all()
    deee =Training.objects.all()
    context = {
        'projects': projects,
        'groups': groups,
        'hafi':hafi,
        'dee':dee,
        'deee':deee,
    }
    return render(request, 'app1/dashboard.html', context)
@login_required
def logout_view(request):
    logout(request)
    return redirect('/thanks')

def thanksview(request):
    return render(request, 'app1/thanks.html')

def signup_view(request):
    form = SignUpForm()
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(user.password)
            user.save()
            return HttpResponseRedirect('/accounts/login')
        else:
            print(form.errors)
    return render(request, 'app1/register.html', {'form': form})
@login_required
def employeesview(request):
    employees = Addnewemployee.objects.all()
    costcenter = Addnewemployee.objects.all()
    inventory = Addnewemployee.objects.all() 
    expenses = Addnewemployee.objects.all() # Retrieve all employees from the database
    training = Addnewemployee.objects.all()
    workexperience = Addnewemployee.objects.all() 
    education = Addnewemployee.objects.all()
    docs = Addnewemployee.objects.all()
    bankdetails = Addnewemployee.objects.all()
    addnewbank = Addnewemployee.objects.all()

    return render(request, 'app1/employees.html', {'employees': employees})
def notifications_view(request):
    # Your view logic here
    return render(request, 'notifications.html')

@login_required
def projectsview(request):
    if request.method == 'POST':
        form = ProjectsForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/addnewprojectdata')
    else:
        form = ProjectsForm()
    return render(request, 'app1/projects.html', {'form': form})
@login_required
def addnewprojectdataview(request):
    projects = Projects.objects.all()
    return render(request, 'app1/addnewprojectdata.html', {'form': projects})



@login_required
def updateaddnewemployee(request, pk):
    employee = get_object_or_404(Addnewemployee, pk=pk)
    if request.method == 'POST':
        form = AddnewemployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewemployeeForm(instance=employee)
    return render(request, 'app1/updateaddnewemployee.html', {'form': form})

@login_required
def deleteaddnewemployee(request, pk):
    employee = get_object_or_404(Addnewemployee, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('/employees')
    return render(request, 'app1/deleteaddnewemployee.html', {'employee': employee})
@login_required
def updateaddnewdepartment(request, pk):
    employee = get_object_or_404(Addnewdepartment, pk=pk)
    if request.method == 'POST':
        form = AddnewdepartmentForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewdepartmentForm(instance=employee)
    return render(request, 'app1/updateaddnewdepartment.html', {'form': form})

@login_required
def deleteaddnewdepartment(request, pk):
    employee = get_object_or_404(Addnewdepartment, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('/employees')
    return render(request, 'app1/deleteaddnewdepartment.html', {'employee': employee})

@login_required
def updateprojectview(request, pk):
    project = get_object_or_404(Projects, pk=pk)
    if request.method == 'POST':
        form = ProjectsForm(request.POST, request.FILES, instance=project)
        if form.is_valid():
            form.save()
            return redirect('addnewprojectdata')
    else:
        form = ProjectsForm(instance=project)
    return render(request, 'app1/updateproject.html', {'form': form})


@login_required
def deleteprojectview(request, pk):
    project = get_object_or_404(Projects, pk=pk)
    if request.method == 'POST':
        project.delete()
        return redirect('addnewprojectdata')
    return render(request, 'app1/deleteproject.html', {'project': project})


# Rest of the view functions remain unchanged
@login_required
def groupsview(request):
    if request.method == 'POST':
        form = GroupsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/addemployeegroups')
    else:
        form = GroupsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/groups.html', {'form': form})
@login_required
def addemployeegroupsview(request):
    groups = Groups.objects.all()
    return render(request, 'app1/addemployeegroups.html', {'form': groups})
@login_required
def requestsview(request):
    return render(request, 'app1/requests.html')
def privacy_policy(request):
    return render(request, 'privacy_policy.html')

@login_required
def costcenterview(request):
    if request.method == 'POST':
        form = CostcenterForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = CostcenterForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/costcenter.html', {'form': form})

@login_required
def leaveapplicationview(request):
    if request.method == 'POST':
        form = LeaveapplicationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/leave')
    else:
        form = LeaveapplicationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/leaveapplication.html', {'form': form})

@login_required
def manageleaveview(request):
   
    return render(request, 'app1/manageleave.html')



@login_required
def leavetypesview(request):
   
    return render(request, 'app1/leavetypes.html')

@login_required
def pendingapprovalview(request):
   
    return render(request, 'app1/pendingapproval.html')

@login_required
def holidaysview(request):
   
    return render(request, 'app1/holidays.html')

@login_required
def leavebulkuploadview(request):
   
    return render(request, 'app1/leavebulkupload.html')

@login_required
def offinlieuallocationview(request):
   
    return render(request, 'app1/offinlieuallocation.html')



@login_required
def leavestatusview(request):
   
    return render(request, 'app1/leavestatus.html')