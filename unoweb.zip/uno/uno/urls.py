"""
URL configuration for uno project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from app1 import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from app1.views import view_biometric_record
from app1.views import login_view, otp_verify_view



urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.homeview),
    
    path('search/', views.searchview, name='search'),
    path('language/<str:language_code>/', views.language_change, name='language_change'),
    path('gmail/', views.gmail, name='gmail'),
    path('dashboard/', views.dashboardview, name='dashboard'),
    path('dashboardpage/', views.dashboardpageview, name='dashboardpage'),
    path('leave/', views.leaveview, name='leave'),
    path('leavebulkupload/', views.leavebulkuploadview, name='leavebulkupload'),
    path('offinlieuallocation/', views.offinlieuallocationview, name='offinlieuallocation'),
    path('leavestatus/', views.leavestatusview, name='leavestatus'),
    path('holidays/', views.holidaysview, name='holidays'),
    path('addnewholiday/', views.addnewholidayview, name='addnewholiday'),
    path('self-service/', views.self_service_view, name='self_service'),
    path('pendingapproval/', views.pendingapprovalview, name='pendingapproval'),
    path('manageleave/', views.manageleaveview, name='manageleave'),
    path('leaveapplication/', views.leaveapplicationview, name='leaveapplication'),
    path('leavetypes/', views.leavetypesview, name='leavetypes'),
    path('addnewleavetype/', views.addnewleavetypeview, name='addnewleavetype'),
    path('security/', views.securityview, name='security'),
    path('switch-company/', views.switch_company, name='switch_company'),
    path('recruitment/', views.recruitment_view, name='recruitment'),
    path('elearning/', views.elearningview, name='elearning'),
    path('appraisal/', views.appraisal_view, name='appraisal'),
    path('polling/', views.polling_view, name='polling'),
    path('employees/', views.employeesview, name='employees'),
    path('departments/', views.departmentsview, name='departments'),
    path('announcement/', views.announcement_view, name='announcement'),
    path('projects/', views.projectsview, name='projects'),
    path('addnewprojectdata/', views.addnewprojectdataview, name='addnewprojectdata'),
    path('Requests/', views.requestsview, name='requests'),
    path('updateproject/<int:pk>/', views.updateprojectview, name='updateproject'),
    path('deleteproject/<int:pk>/', views.deleteprojectview, name='deleteproject'),
    path('updateaddnewemployee/<int:pk>/', views.updateaddnewemployee, name='updateaddnewemployee'),
    path('deleteaddnewemployee/<int:pk>/', views.deleteaddnewemployee, name='deleteaddnewemployee'),
    path('updateaddnewdepartment/<int:pk>/', views.updateaddnewdepartment, name='updateaddnewdepartment'),
    path('deleteaddnewdepartment/<int:pk>/', views.deleteaddnewdepartment, name='deleteaddnewdepartment'),
    path('groups/', views.groupsview, name='groups'),
    path('addemployeegroups/', views.addemployeegroupsview, name='addemployeegroups'),
    path('addnewemployee/', views.addnewemployeeview, name='addnewemployee'),
    path('addnewdepartment/', views.addnewdepartmentview, name='addnewdepartment'),
    path('onboarding/', views.onboardingview, name='onboarding'),
    path('employee/', views.employeeview, name='employee'),
    path('requests/', views.requestsview, name='requests'),
    path('accounts/login/', login_view, name='login'),
    path('accounts/otp_verify/', otp_verify_view, name='otp_verify'),
  
    path('logout/',views.logout_view, name='logout'),
    path('handbook/', views.handbook_view, name='handbook'),  # Ensure this pattern is defined
    path('thanks/', views.thanksview),
    path('costcenter/', views.costcenterview, name='costcenter'),
    path('inventory/', views.inventoryview, name='inventory'),
    path('education/', views.educationview, name='education'),
    path('addnewbank/', views.addnewbankview, name='addnewbank'),
    path('bankdetails/', views.bankdetailsview, name='bankdetails'), 
    path('docs/', views.docsview, name='docs'),
    path('workexperience/', views.workexperienceview, name='workexperience'),
    path('training/', views.trainingview, name='training'),
    path('expenses/', views.expensesview, name='expenses'),
    path('feedback/', views.feedbackview, name='feedback'),
    path('register/', views.signup_view),
    path('enhancements/', views.enhancements_view, name='enhancements'),
    path('guide/', views.guide_view, name='guide'),  # Add this line,
    path('faqs/', views.faqs_view, name='faqs'),
    path('support/', views.support_view, name='support'),
    path('audit-logs/', views.audit_logs_view, name='audit_logs'),
    path('claim/', views.claimview, name='claim'), 
    path('claimapplication/', views.claimapplicationview, name='claimapplication'), 
    path('claimstatus/', views.claimstatusview, name='claimstatus'),
    path('claimpendingapproval/', views.claimpendingapprovalview, name='claimpendingapproval'),
    path('timesheet/', views.timesheetview, name='timesheet'),
    path('dailytimesheet/', views.dailytimesheetview, name='dailytimesheet'),
    path('claimsupload/', views.claimsuploadview, name='claimsupload'),
    path('timesheetmanagement/', views.timesheetmanagementview, name='timesheetmanagement'),
    path('create/', views.createview, name='create'),
    path('manageshifts/update/<int:shift_id>/', views.update_shift, name='update_shift'),
    path('manageshifts/delete/<int:shift_id>/', views.delete_shift, name='delete_shift'),
    path('manageshifts/copy/<int:shift_id>/', views.copy_shift, name='copy_shift'),
    path('overtimehours/', views.overtimehoursview, name='overtimehours'),
    path('ottimesheet/', views.ottimesheetview, name='ottimesheet'),
    path('importtimesheet/', views.importtimesheetview, name='importtimesheet'),
    path('timesheetadd/', views.timesheetaddview, name='timesheetadd'),
    path('project/<int:project_id>/', views.project_view, name='project-view'),
    path('monthlytimesheet/', views.monthlytimesheetview, name='monthlytimesheet'),
    path('manageshifts/', views.manageshiftsview, name='manageshifts'),
    path('biometriclog/', views.biometriclogview, name='biometriclog'),
    path('biometriclogrecords/view/<int:record_id>/', view_biometric_record, name='view_biometric_record'),
    path('biometriclogrecords/', views.biometriclogrecordsview, name='biometriclogrecords'),
    path('addnewshifts/', views.addnewshiftsview, name='addnewshifts'),
    path('approvetimesheet/', views.approvetimesheetview, name='approvetimesheet'),
    path('group/<int:group_id>/', views.group_view, name='group-view'),
    path('projectattendance/', views.projectattendanceview, name='projectattendance'),
    path('timesheet/', views.timesheetview, name='timesheet'),
    path('rosterlist/', views.rosterlistview, name='rosterlist'),
    path('roster/update/<int:id>/', views.roster_update, name='roster_update'),
    path('roster/delete/<int:id>/', views.roster_delete, name='roster_delete'),
    path('roster/copy/<int:id>/', views.roster_copy, name='roster_copy'),
    path('scheduling/', views.scheduling_view, name='scheduling'),
    path('payroll/', views.payrollview, name='payroll'),
    path('reports/', views.reports_view, name='reports'),
    path('settings/', views.settingsview, name='settings'),
    path('manageworkflow/', views.manageworkflowview, name='manageworkflow'),
    path('managesecurity/', views.managesecurityview, name='managesecurity'),
    path('copy/<int:pk>/', views.copy_user_right, name='copy_user_right'),
    path('delete/<int:pk>/', views.delete_user_right, name='delete_user_right'),
    path('addnewworkflow/', views.addnewworkflowview, name='addnewworkflow'),
    path('workflow/update/<int:pk>/', views.update_workflow_view, name='update_workflow'),
    path('workflow/delete/<int:pk>/', views.delete_workflow_view, name='delete_workflow'),
    path('privacy-policy/', views.privacy_policy, name='privacy_policy'),
    path('expenses_view/', views.expenses_viewview, name='expenses_view'),
    path('notifications/', views.notifications_view, name='notifications'),

 
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



