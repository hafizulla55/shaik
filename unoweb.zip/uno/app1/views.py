from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.models import User  # Add this import
from app1.forms import (SignUpForm, ProjectsForm, GroupsForm, AddnewemployeeForm, EmployeeForm, 
                        AddnewdepartmentForm, CostcenterForm, ExpensesForm, InventoryForm, TrainingForm, 
                        WorkexperienceForm, EducationForm, DocsForm, BankdetailsForm, AddnewbankForm, 
                        LeaveapplicationForm, AddnewleavetypeForm, AddnewholidayForm, LeavebulkuploadForm, 
                        OffinlieuallocationForm, ClaimapplicationForm, ClaimsuploadForm, CreateForm, 
                        ImporttimesheetForm, TimesheetaddForm, AddnewshiftsForm, BiometriclogrecordsForm, 
                        AddnewworkflowForm, ManagesecurityForm)
from .models import (Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, 
                     Expenses, Inventory, Training, Workexperience, Education, Docs, Bankdetails, 
                     Addnewbank, Leaveapplication, Addnewleavetype, Addnewholiday, Leavebulkupload, 
                     Offinlieuallocation, Claimapplication, Claimsupload, Create, Importtimesheet, 
                     Timesheetadd, Addnewshifts, Biometriclogrecords, Addnewworkflow, Managesecurity)
from django.http import HttpResponseRedirect
from django import forms
import random
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.forms import AuthenticationForm
from django.utils.timezone import now



@login_required
def dashboardpageview(request):
    today = now().date()
    total_users = User.objects.count()
    logged_in_today = User.objects.filter(last_login__date=today).count()
    
    context = {
        'total_users': total_users,
        'logged_in_today': logged_in_today,
    }
    return render(request,'app1/dashboardpage.html', context)

@login_required
def logout_view(request):
    logout(request)
    return redirect('/thanks')

def thanksview(request):
    return render(request, 'app1/thanks.html')

# OTP verification view
def otp_verify_view(request):
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')
        username = request.session.get('username')
        
        if entered_otp == stored_otp:
            # OTP is correct, log the user in and redirect to dashboard
            user = User.objects.get(username=username)
            login(request, user)
            return HttpResponseRedirect('/dashboardpage/')
        else:
            # OTP is incorrect
            return render(request, 'app1/otp_verify.html', {'error': 'Invalid OTP'})
    
    return render(request, 'app1/otp_verify.html')

# Function to generate OTP
def generate_otp():
    return str(random.randint(100000, 999999))

def login_view(request):
    form = AuthenticationForm()  # Use Django's built-in authentication form
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                otp = generate_otp()
                request.session['otp'] = otp  # store OTP in session
                request.session['username'] = username  # store username
                send_mail(
                    'Your OTP for Login',
                    f'Your OTP is: {otp}',
                    settings.DEFAULT_FROM_EMAIL,
                    [user.email],  # send OTP to the user's registered email
                )
                return redirect('otp_verify')  # Redirect to OTP verification page
            else:
                return render(request, 'app1/login.html', {'form': form, 'error': 'Invalid credentials'})
    
    return render(request, 'app1/login.html', {'form': form})

def test_email(request):
    send_mail(
        'Test Subject',
        'This is a test message.',
        'hafizullab7@gmail.com',
        ['hafizullab7@gmail.com'],
        fail_silently=False,
    )
    return HttpResponse("Test email sent successfully")



def signup_view(request):
    form = SignUpForm()
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(user.password)
            user.save()
            return HttpResponseRedirect('/accounts/login')
        else:
            print(form.errors)
    return render(request, 'app1/register.html', {'form': form})

# Copy user right view
def copy_user_right(request, pk):
    user_right = get_object_or_404(Managesecurity, pk=pk)
    user_right.pk = None  # This will create a copy with a new ID
    user_right.save()
    messages.success(request, 'User right copied successfully!')
    return redirect('managesecurity')  # Redirect to your desired page

def delete_user_right(request, pk):
    user_right = get_object_or_404(Managesecurity, pk=pk)
    user_right.delete()
    messages.success(request, 'User right deleted successfully!')
    return redirect('managesecurity')  # Redirect to your desired page

@login_required
def managesecurityview(request):
    managesecurity_list = Managesecurity.objects.all() 
    return render(request, 'app1/managesecurity.html', {'managesecurity_list': managesecurity_list})

@login_required
def managesecurityview(request):
    if request.method == 'POST':
        form = ManagesecurityForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('managesecurity')  # Replace with your success URL or view
    else:
        form = ManagesecurityForm()
    return render(request, 'app1/managesecurity.html', {'form': form, 'managesecurity_list': Managesecurity.objects.all()})



@login_required
def claimstatusview(request):
    return render(request, 'app1/claimstatus.html')


@login_required
def addnewholidayview(request):
    if request.method == 'POST':
        form = AddnewholidayForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('holidays')  # Replace with your success URL or view
    else:
        form = AddnewholidayForm()

    return render(request, 'app1/addnewholiday.html', {'form': form})


def announcement_view(request):
    return render(request, 'announcement.html')
@login_required
def departmentsview(request):
    Add = Addnewdepartment.objects.all() 
    return render(request, 'app1/departments.html',{'f':Add})


def handbook_view(request):
    # Your view logic here
    return render(request, 'handbook.html')
    
@login_required
def addnewdepartmentview(request):
    if request.method == 'POST':
        form = AddnewdepartmentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/departments')
    else:
        form = AddnewdepartmentForm()
    return render(request, 'app1/addnewdepartment.html', {'form': form})


@login_required
def addnewemployeeview(request):
    if request.method == 'POST':
        form = AddnewemployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewemployeeForm()
    return render(request, 'app1/addnewemployee.html', {'form': form})



def employeeview(request):
    form = EmployeeForm()  # Assuming 'EmployeeForm' is your form class
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, 'app1/employee.html', {'form': form})


@login_required
def project_view(request, project_id):
    projects = get_object_or_404(Projects, pk=project_id)
    return render(request, 'app1/project_detail.html', {'project': projects})

@login_required
def projectattendanceview(request):
    proj = Projects.objects.all()  # Retrieve all employees from the database
    return render(request, 'app1/projectattendance.html', {'f': proj})

@login_required
def ottimesheetview(request):
    eid = Groups.objects.all()
   
    return render(request, 'app1/ottimesheet.html', {'f': eid})


def group_view(request, project_id):
    groups = get_object_or_404(Groups, pk=group_id)
    return render(request, 'app1/group_detail.html', {'group': groups})

@login_required
def onboardingview(request):
    employees = Addnewemployee.objects.all()  # Retrieve all employees from the database
    return render(request, 'app1/onboarding.html', {'employees': employees})

@login_required
def expensesview(request):
    if request.method == 'POST':
        form = ExpensesForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = ExpensesForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/expenses.html', {'form': form})

@login_required
def inventoryview(request):
    if request.method == 'POST':
        form = InventoryForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = InventoryForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/inventory.html', {'form': form})


@login_required
def workexperienceview(request):
    if request.method == 'POST':
        form = WorkexperienceForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = WorkexperienceForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/workexperience.html', {'form': form})

@login_required
def educationview(request):
    if request.method == 'POST':
        form = EducationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = EducationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/education.html', {'form': form})

@login_required
def docsview(request):
    if request.method == 'POST':
        form = DocsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = DocsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/docs.html', {'form': form})

@login_required
def addnewbankview(request):
    if request.method == 'POST':
        form = AddnewbankForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewbankForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/addnewbank.html', {'form': form})



@login_required
def bankdetailsview(request):
    if request.method == 'POST':
        form = BankdetailsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = BankdetailsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/bankdetails.html', {'form': form})

@login_required
def trainingview(request):
    if request.method == 'POST':
        form = TrainingForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = TrainingForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/training.html', {'form': form})

def language_change(request, language_code):
    # Logic to change the language
    return redirect('home')  # Redirect or render appropriate response
def searchview(request):
    # Your logic here
    return render(request, 'app1/search.html')
@login_required
def guide_view(request):
    return render(request, 'app1/guide.html')
@login_required
def faqs_view(request):
    return render(request, 'app1/faqs.html')
@login_required
def support_view(request):
    return render(request, 'app1/support.html')
@login_required
def audit_logs_view(request):
    return render(request, 'app1/audit_logs.html')

@login_required
def leaveview(request):
    leaveapplication = Leaveapplication.objects.all()

   
    return render(request, 'app1/leave.html', {'leave': leaveapplication})

@login_required
def claimview(request):
   
    if request.method == 'GET':
       
        claimapplication = None

       
        try:
            claimapplication = Claimapplication.objects.all()
        except Claimapplication.DoesNotExist:
           
            claimapplication = None

      
        return render(request, 'app1/claim.html', {'claimapplication': claimapplication})

@login_required
def claimapplicationview(request):
    if request.method == 'POST':
        form = ClaimapplicationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/claim')
    else:
        form = ClaimapplicationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/claimapplication.html', {'form': form})


@login_required
def claimpendingapprovalview(request):
    claims = Claimapplication.objects.all()  # Query the Claimpendingapproval table
    return render(request, 'app1/claimpendingapproval.html', {'claims': claims})

@login_required
def timesheetview(request):
    claims = Claimapplication.objects.all()  # Query the Claimpendingapproval table
    return render(request, 'app1/timesheet.html', {'claims': claims})

@login_required
def claimsuploadview(request):
    if request.method == 'POST':
        form = ClaimsuploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/claim')
    else:
        form = ClaimsuploadForm()

    claims = Claimsupload.objects.all()  # Fetch all claims to display in the table

    return render(request, 'app1/claimsupload.html', {'form': form, 'claims': claims})




@login_required
def update_shift(request, shift_id):
    addnewshifts = get_object_or_404(Addnewshifts, pk=shift_id)  # Use the correct model 'Addnewshifts'
    if request.method == 'POST':
        form = AddnewshiftsForm(request.POST, instance=addnewhifts)
        if form.is_valid():
            form.save()
            return redirect('rosterlist')  # Redirect to your desired view after saving
    else:
        form = AddnewshiftsForm(instance=addnewshifts)  # Use the correct form instance
    return render(request, 'app1/update_shift.html', {'form': form})

# View to delete a shift
def delete_shift(request, shift_id):
    addnewshifts = get_object_or_404(Addnewshifts, pk=shift_id)
    if request.method == 'POST':
        addnewshifts.delete()
        return redirect('rosterlist')
    return render(request, 'app1/delete_shift.html', {'shift': addnewshifts})

# View to copy a shift (create a new shift with the same data)
def copy_shift(request, shift_id):
    addnewshifts = get_object_or_404(Addnewshifts, pk=shift_id)
    if request.method == 'POST':
        addnewshifts.pk = None  # Set the primary key to None to create a new instance
        addnewshifts.save()
        return redirect('rosterlist')
    return render(request, 'app1/copy_shift.html', {'shift': addnewshifts})

def reports_view(request):
    return render(request, 'reports.html')

def view_biometric_record(request, record_id):
    try:
        # Retrieve the specific biometric record by its ID
        record = Biometriclogrecords.objects.get(id=record_id)
    except Biometriclogrecords.DoesNotExist:
        record = None  # Handle case if the record doesn't exist

    context = {'record': record}
    return render(request, 'app1/biometriclog.html', context)

@login_required
def biometriclogrecordsview(request):
    if request.method == 'POST':
        form = BiometriclogrecordsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/biometriclog')  # Redirect to a list or success page after saving
    else:
        form = BiometriclogrecordsForm()

    return render(request, 'app1/biometriclogrecords.html', {'form': form})

@login_required
def biometriclogview(request):
    records = Biometriclogrecords.objects.all()
    return render(request, 'app1/biometriclog.html', {'records': records})


@login_required   
def timesheetmanagementview(request):
     
   return render(request, 'app1/timesheetmanagement.html')

@login_required
def importtimesheetview(request):
    if request.method == 'POST':
        form = ImporttimesheetForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/timesheetmanagement')
    else:
        form = ImporttimesheetForm()

    return render(request, 'app1/importtimesheet.html', {'form': form})

@login_required
def timesheetaddview(request):
    if request.method == 'POST':
        form = TimesheetaddForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/timesheetmanagement')
    else:
        form = TimesheetaddForm()

    return render(request, 'app1/timesheetadd.html', {'form': form})

@login_required
def createview(request):
    if request.method == 'POST':
        form = CreateForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/timesheetmanagement')
    else:
        form = CreateForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/create.html', {'form': form})

@login_required
def rosterlistview(request):
    create = Create.objects.all()
    return render(request, 'app1/rosterlist.html', {'f': create})


@login_required
def roster_update(request, id):
    create = get_object_or_404(Create, id=id)
    if request.method == 'POST':
        form = CreateForm(request.POST, instance=create)
        if form.is_valid():
            form.save()
            return redirect('rosterlist')  # Assuming you have a view that lists all rosters
    else:
        form = CreateForm(instance=create)
    
    return render(request, 'app1/roster_update.html', {'form': form})


@login_required
def roster_delete(request, id):
    create = get_object_or_404(Create, id=id)
    if request.method == 'POST':
        create.delete()
        return redirect('rosterlist')  # Redirect to the list view after deletion
    return render(request, 'roster_confirm_delete.html', {'create': create})

@login_required
def roster_copy(request, id):
    create = get_object_or_404(Create, id=id)
    if request.method == 'POST':
        form = RosterlistForm(request.POST)
        if form.is_valid():
            new_roster = form.save(commit=False)
            new_roster.id = None  # Ensure the new instance gets a new ID
            new_roster.save()
            return redirect('rosterlist')
    else:
        # Create a form pre-filled with the existing roster's data
        form = CreateForm(instance=create)
    
    return render(request, 'app1/roster_copy.html', {'form': form})

@login_required    
def dailytimesheetview(request):
    create = Create.objects.all()
    return render(request, 'app1/dailytimesheet.html', {'f': create})


@login_required    
def monthlytimesheetview(request):
    create = Create.objects.all()
    return render(request, 'app1/monthlytimesheet.html', {'f': create})

@login_required    
def approvetimesheetview(request):
    create = Create.objects.all()
    return render(request, 'app1/approvetimesheet.html', {'f': create})

@login_required
def overtimehoursview(request):
    create = Create.objects.all()  # Assuming the model for shifts is called 'Addnewshifts'
    return render(request, 'app1/overtimehours.html', {'f': create})

@login_required
def manageshiftsview(request):
    shifts = Addnewshifts.objects.all()  # Assuming the model for shifts is called 'Addnewshifts'
    return render(request, 'app1/manageshifts.html', {'shifts': shifts})

@login_required
def addnewshiftsview(request):
    if request.method == 'POST':
        form = AddnewshiftsForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/manageshifts')
    else:
        form = AddnewshiftsForm()

    return render(request, 'app1/addnewshifts.html', {'form': form})





def scheduling_view(request):
    return render(request, 'scheduling.html')
def payrollview(request):
    return render(request, 'app1/payroll.html')
def leave_view(request):
    # Your view logic here
    return render(request, 'leave.html')


def elearningview(request):
    return render(request, 'app1/elearning.html')

def self_service_view(request):
    return render(request, 'self_service.html')
def gmail(request):
    # Your logic here
    return render(request, 'gmail.html')
def appraisal_view(request):
    return render(request, 'appraisal.html')
def recruitment_view(request):
    return render(request, 'recruitment.html')


@login_required    
def settingsview(request):
    return render(request, 'app1/settings.html')

@login_required    
def manageworkflowview(request):
    ADNW = Addnewworkflow.objects.all()
    return render(request, 'app1/manageworkflow.html', {'adnw': ADNW})

@login_required    
def addnewworkflowview(request):
    if request.method == 'POST':
        form = AddnewworkflowForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manageworkflow')
    else:
        form = AddnewworkflowForm()
    return render(request, 'app1/addnewworkflow.html', {'form': form})

@login_required
def update_workflow_view(request, pk):
    workflow = get_object_or_404(Addnewworkflow, id=pk)
    if request.method == 'POST':
        form = AddnewworkflowForm(request.POST, instance=workflow)
        if form.is_valid():
            form.save()
            return redirect('manageworkflow')
    else:
        form = AddnewworkflowForm(instance=workflow)
    return render(request, 'app1/update_workflow.html', {'form': form})

@login_required
def delete_workflow_view(request, pk):
    workflow = get_object_or_404(Addnewworkflow, id=pk)
    if request.method == 'POST':
        workflow.delete()
        return redirect('manageworkflow')
    return render(request, 'app1/delete_workflow.html', {'workflow': workflow})

def switch_company(request):
    return render(request, 'switch_company.html')
def notifications(request):
    # Your logic here
    return render(request, 'notifications.html')
def expenses_view(request):
    return render(request, 'expenses.html')
def feedbackview(request):
    return render(request, 'app1/feedback.html')
def polling_view(request):
    return render(request, 'polling.html')

@login_required
def securityview(request):
    return render(request, 'app1/security.html')


@login_required
def announcement_view(request):
    return render(request, 'app1/announcement.html')
@login_required
def handbook_view(request):
    return render(request, 'app1/handbook.html')
@login_required
def enhancements_view(request):
    return render(request, 'app1/enhancements.html')

@login_required
def homeview(request):
    return render(request, 'app1/home.html')


@login_required
def expenses_viewview(request):
    return render(request, 'app1/expenses_view.html')

@login_required
def dashboardview(request):

    projects = Projects.objects.all()  # Replace with your actual model
    groups = Groups.objects.all()  # Replace with your actual model
    hafi = Addnewemployee.objects.all() 
    dee =Inventory.objects.all()
    deee =Training.objects.all()
    abc =Leaveapplication.objects.all()
    mno =Leavebulkupload.objects.all()
    ppt =Offinlieuallocation.objects.all()
    ccc =Claimapplication.objects.all()
    context = {
        'projects': projects,
        'groups': groups,
        'hafi':hafi,
        'dee':dee,
        'deee':deee,
        'abc':abc,
        'mno':mno,
        'ppt':ppt,
        'ccc':ccc,
    }
    return render(request, 'app1/dashboard.html', context)

@login_required
def employeesview(request):
    employees = Addnewemployee.objects.all()
    costcenter = Addnewemployee.objects.all()
    inventory = Addnewemployee.objects.all() 
    expenses = Addnewemployee.objects.all() # Retrieve all employees from the database
    training = Addnewemployee.objects.all()
    workexperience = Addnewemployee.objects.all() 
    education = Addnewemployee.objects.all()
    docs = Addnewemployee.objects.all()
    bankdetails = Addnewemployee.objects.all()
    addnewbank = Addnewemployee.objects.all()

    return render(request, 'app1/employees.html', {'employees': employees})
def notifications_view(request):
    # Your view logic here
    return render(request, 'notifications.html')

@login_required
def projectsview(request):
    if request.method == 'POST':
        form = ProjectsForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/addnewprojectdata')
    else:
        form = ProjectsForm()
    return render(request, 'app1/projects.html', {'form': form})
@login_required
def addnewprojectdataview(request):
    projects = Projects.objects.all()
    return render(request, 'app1/addnewprojectdata.html', {'form': projects})



@login_required
def updateaddnewemployee(request, pk):
    employee = get_object_or_404(Addnewemployee, pk=pk)
    if request.method == 'POST':
        form = AddnewemployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewemployeeForm(instance=employee)
    return render(request, 'app1/updateaddnewemployee.html', {'form': form})

@login_required
def deleteaddnewemployee(request, pk):
    employee = get_object_or_404(Addnewemployee, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('/employees')
    return render(request, 'app1/deleteaddnewemployee.html', {'employee': employee})
@login_required
def updateaddnewdepartment(request, pk):
    employee = get_object_or_404(Addnewdepartment, pk=pk)
    if request.method == 'POST':
        form = AddnewdepartmentForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = AddnewdepartmentForm(instance=employee)
    return render(request, 'app1/updateaddnewdepartment.html', {'form': form})

@login_required
def deleteaddnewdepartment(request, pk):
    employee = get_object_or_404(Addnewdepartment, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('/employees')
    return render(request, 'app1/deleteaddnewdepartment.html', {'employee': employee})

@login_required
def updateprojectview(request, pk):
    project = get_object_or_404(Projects, pk=pk)
    if request.method == 'POST':
        form = ProjectsForm(request.POST, request.FILES, instance=project)
        if form.is_valid():
            form.save()
            return redirect('addnewprojectdata')
    else:
        form = ProjectsForm(instance=project)
    return render(request, 'app1/updateproject.html', {'form': form})


@login_required
def deleteprojectview(request, pk):
    project = get_object_or_404(Projects, pk=pk)
    if request.method == 'POST':
        project.delete()
        return redirect('addnewprojectdata')
    return render(request, 'app1/deleteproject.html', {'project': project})


# Rest of the view functions remain unchanged
@login_required
def groupsview(request):
    if request.method == 'POST':
        form = GroupsForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/addemployeegroups')
    else:
        form = GroupsForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/groups.html', {'form': form})

@login_required
def addemployeegroupsview(request):
    groups = Groups.objects.all()
    return render(request, 'app1/addemployeegroups.html', {'form': groups})

@login_required
def requestsview(request):
    return render(request, 'app1/requests.html')

def privacy_policy(request):
    return render(request, 'privacy_policy.html')

@login_required
def costcenterview(request):
    if request.method == 'POST':
        form = CostcenterForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/employees')
    else:
        form = CostcenterForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/costcenter.html', {'form': form})

@login_required
def leaveapplicationview(request):
    if request.method == 'POST':
        form = LeaveapplicationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/leave')
    else:
        form = LeaveapplicationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/leaveapplication.html', {'form': form})

@login_required
def manageleaveview(request):
   
    return render(request, 'app1/manageleave.html')

@login_required
def pendingapprovalview(request):
    pen = Leaveapplication.objects.all()
    return render(request, 'app1/pendingapproval.html', {'f': pen})

@login_required
def holidaysview(request):
    holidays = Addnewholiday.objects.all()  # Fetch all holidays
    return render(request, 'app1/holidays.html', {'holidays': holidays})  # Send data to template

@login_required
def leavebulkuploadview(request):
    if request.method == 'POST':
        form = LeavebulkuploadForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/leave')
    else:
        form = LeavebulkuploadForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/leavebulkupload.html', {'form': form})

@login_required
def offinlieuallocationview(request):
    if request.method == 'POST':
        form = OffinlieuallocationForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/leave')
    else:
        form = OffinlieuallocationForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/offinlieuallocation.html', {'form': form})

@login_required
def addnewleavetypeview(request):
    if request.method == 'POST':
        form = AddnewleavetypeForm(request.POST, request.FILES)  # Use GroupsForm instead of AddemployeegroupsForm
        if form.is_valid():
            form.save()
            return redirect('/leave')
    else:
        form = AddnewleavetypeForm()  # Use GroupsForm instead of AddemployeegroupsForm
    return render(request, 'app1/addnewleavetype.html', {'form': form})

@login_required
def leavestatusview(request):
   
    return render(request, 'app1/leavestatus.html')

@login_required
def addnewleavetypeview(request):
    f = AddnewleavetypeForm()
    if request.method == "POST":
        f = AddnewleavetypeForm(request.POST)
        if f.is_valid():
            f.save()
            return redirect('/leavetypes')
    return render(request, 'app1/addnewleavetype.html', {'form':f})



@login_required
def leavetypesview(request):
    ty=Addnewleavetype.objects.all()
    return render(request, 'app1/leavetypes.html',{'f':ty})