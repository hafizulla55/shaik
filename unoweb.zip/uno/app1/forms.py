from django import forms
from django.contrib.auth.models import User
from .models import Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, Expenses, Inventory, Training, Workexperience, Education, Docs, Addnewbank, Bankdetails, Leaveapplication, Addnewleavetype, Addnewholiday, Leavebulkupload, Offinlieuallocation, Claimapplication, Claimsupload, Create, Importtimesheet, Timesheetadd, Addnewshifts, Biometriclogrecords, Addnewworkflow, Managesecurity
from django.core.exceptions import ValidationError




class SignUpForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'first_name', 'last_name']

class ProjectsForm(forms.ModelForm):
    class Meta:
        model = Projects
        fields = ['project_id', 'photograph', 'project_name', 'department', 'group', 'employee', 'shift', 'supervisor',
                  'description', 'public_holiday', 'rest_day']

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee  # Assuming you have an Employee model
        fields = '__all__'
        widgets = {
            'field_name': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'another_field': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            # Add similar entries for other fields
        }

class GroupsForm(forms.ModelForm):
    class Meta:
        model = Groups
        fields = ['group_id', 'photograph', 'group_name', 'department', 'projects', 'employees']

class AddnewemployeeForm(forms.ModelForm):
    class Meta:
        model = Addnewemployee
        fields = '__all__'

class AddnewdepartmentForm(forms.ModelForm):
    class Meta:
        model = Addnewdepartment
        fields = '__all__'

class CostcenterForm(forms.ModelForm):
    class Meta:
        model = Costcenter
        fields = '__all__'


class ExpensesForm(forms.ModelForm):
    class Meta:
        model = Expenses
        fields = '__all__'

class InventoryForm(forms.ModelForm):
    class Meta:
        model = Inventory
        fields = '__all__'

class TrainingForm(forms.ModelForm):
    class Meta:
        model = Training
        fields = '__all__'

class WorkexperienceForm(forms.ModelForm):
    class Meta:
        model = Workexperience
        fields = '__all__'


class EducationForm(forms.ModelForm):
    class Meta:
        model = Education
        fields = '__all__'


class BiometriclogrecordsForm(forms.ModelForm):
    class Meta:
        model = Biometriclogrecords
        fields = '__all__'

class DocsForm(forms.ModelForm):
    class Meta:
        model = Docs
        fields = '__all__'


class AddnewbankForm(forms.ModelForm):
    class Meta:
        model = Addnewbank
        fields = '__all__'

class BankdetailsForm(forms.ModelForm):
    class Meta:
        model = Bankdetails
        fields = '__all__'

class LeaveapplicationForm(forms.ModelForm):
    class Meta:
        model = Leaveapplication
        fields = '__all__'

class AddnewleavetypeForm(forms.ModelForm):
    class Meta:
        model = Addnewleavetype
        fields = '__all__'


class AddnewholidayForm(forms.ModelForm):
    class Meta:
        model = Addnewholiday
        fields = ['name', 'calendar']
        widgets = {
            'calendar': forms.DateInput(attrs={'type': 'date'}),
        }

class LeavebulkuploadForm(forms.ModelForm):
   class Meta:
       model  = Leavebulkupload
       fields = '__all__'

class OffinlieuallocationForm(forms.ModelForm):
   class Meta:
       model  = Offinlieuallocation
       fields = '__all__'   


class ClaimapplicationForm(forms.ModelForm):
    class Meta:
        model = Claimapplication
        fields = ['employee_name', 'claim_type', 'from_date', 'to_date', 'project_name', 'custom_claim', 'receipt_id',
                  'attachment1', 'attachment2', 'description', 'currency', 'exchange_rate', 'quantity', 'amount', 'gst']
        widgets = {
            'from_date': forms.DateInput(attrs={'type': 'date'}),  # Calendar input for 'from_date'
            'to_date': forms.DateInput(attrs={'type': 'date'})  # Calendar input for 'to_date'
        }
class ClaimsuploadForm(forms.ModelForm):
    class Meta:
        model = Claimsupload
        fields = ['upload_document']

class ImporttimesheetForm(forms.ModelForm):
    class Meta:
        model = Importtimesheet
        fields = ['upload_document']


class TimesheetaddForm(forms.ModelForm):
    class Meta:
        model = Timesheetadd
        fields ='__all__'
        widgets = {

            'date': forms.DateInput(attrs={'type': 'date'}),  # 'date' in lowercase
            'in_time': forms.TimeInput(attrs={'type': 'time'}),  # 'time' in lowercase
            'out_time': forms.TimeInput(attrs={'type': 'time'}),  
        }

class CreateForm(forms.ModelForm):
    class Meta:
        model = Create
        fields = '__all__'
        widgets = {
            'Roster_From_Period': forms.DateInput(attrs={'type': 'date'}),  # 'date' in lowercase
            'Roster_To_Period': forms.DateInput(attrs={'type': 'date'}),
            'In_Time': forms.TimeInput(attrs={'type': 'time'}),  # 'time' in lowercase
            'Out_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Earliest_Clock_In_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Last_Clock_Out_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Late_In_From': forms.TimeInput(attrs={'type': 'time'}),
        }


class AddnewshiftsForm(forms.ModelForm):
    # Add a color picker for the Pick_Color field
    Pick_Color = forms.CharField(widget=forms.TextInput(attrs={'type': 'color'}))  # Color picker
    
    # Add radio buttons for the Roster_Settings field
    Roster_Settings = forms.ChoiceField(
        choices=Addnewshifts.SHIFT_ROSTER_CHOICES, 
        widget=forms.RadioSelect  # Radio buttons
    )
    
    class Meta:
        model = Addnewshifts
        fields = [
            'Shift_Id', 'Shift_Name', 'Pick_Color', 'In_Time', 'Out_Time', 
            'Earliest_Clock_In_Time', 'Last_Clock_Out_Time', 'Auto_Clock_Out', 
            'Break_Time_Normal_Hours', 'OT_Break_Time_Normal_Hours', 
            'OT_To_Only_Start_After', 'OT_Break_Takes_Effect_After', 'Late_In_From', 
            'Apply_Days', 'Basic_Pay', 'Custom_Fine', 'Fixed', 'Roster_Settings', 
            'Amount_Per_Min', 'Poster_Code', 'Supervisor_Name'
        ]

        widgets = {
            'In_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Out_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Earliest_Clock_In_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Last_Clock_Out_Time': forms.TimeInput(attrs={'type': 'time'}),
            'Late_In_From': forms.TimeInput(attrs={'type': 'time'}),
        }
class ManagesecurityForm(forms.ModelForm):
    class Meta:
        model = Managesecurity  # Corrected model name
        fields = ['add_new_user_right']  # Remove extra space inside the field name

class AddnewworkflowForm(forms.ModelForm):
    class Meta:
        model = Addnewworkflow
        fields = ['manage_workflow', 'workflow_name', 'department', 'group', 'projects', 'employee', 'levels']
        widgets = {
            'manage_workflow': forms.Select(attrs={'class': 'form-control'}),
            'workflow_name': forms.TextInput(attrs={'class': 'form-control'}),
            'department': forms.Select(attrs={'class': 'form-control'}),
            'group': forms.Select(attrs={'class': 'form-control'}),
            'projects': forms.Select(attrs={'class': 'form-control'}),
            'employee': forms.Select(attrs={'class': 'form-control'}),
            'levels': forms.Select(attrs={'class': 'form-control'}),
        }