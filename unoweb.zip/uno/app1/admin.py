from django.contrib import admin
from .models import Projects, Groups, Addnewemployee, Employee, Addnewdepartment, Costcenter, Expenses, Inventory, Training, Workexperience, Education, Docs, Addnewbank, Bankdetails, Leaveapplication, Addnewleavetype, Addnewholiday, Leavebulkupload, Offinlieuallocation, Claimapplication, Claimsupload, Create, Importtimesheet, Timesheetadd, Addnewshifts, Biometriclogrecords, Addnewworkflow, Managesecurity 
from .forms import ProjectsForm, GroupsForm, AddnewemployeeForm, EmployeeForm, AddnewdepartmentForm, CostcenterForm, ExpensesForm, InventoryForm, TrainingForm, WorkexperienceForm, EducationForm, DocsForm, AddnewbankForm, BankdetailsForm, LeaveapplicationForm, AddnewleavetypeForm, AddnewholidayForm, LeavebulkuploadForm, OffinlieuallocationForm, ClaimapplicationForm, ClaimsuploadForm, CreateForm, ImporttimesheetForm, TimesheetaddForm, AddnewshiftsForm, BiometriclogrecordsForm, AddnewworkflowForm, ManagesecurityForm







class CreateAdmin(admin.ModelAdmin):
    list_display = ('Roster_Name','Select_Days','Roster_From_Period','Roster_To_Period',
        'Groups','Project','Employee','In_Time','Out_Time','Earliest_Clock_In_Time',
        'Last_Clock_Out_Time','Auto_Clock_Out','Break_Time_Normal_Hours','OT_Break_Time_Normal_Hours',
        'OT_To_Only_Start_After','OT_Break_Takes_Effect_After','Late_In_From','Apply_Days',
        'Basic_Pay','Custom_Fine','Fixed','Common_OT','Hourly_OT','Total_OT_Hours',
        'Off_in_Lieu','Default','MOM_Regulation','OT_By_Minutes','OT_By_Block_30mins','OT_By_Block_15mins')

admin.site.register(Create, CreateAdmin)

class ManagesecurityAdmin(admin.ModelAdmin):
    list_display = ('add_new_user_right',)

# Register the model with the admin class
admin.site.register(Managesecurity, ManagesecurityAdmin)

@admin.register(Addnewworkflow)
class AddnewworkflowAdmin(admin.ModelAdmin):
    list_display = ['workflow_name', 'manage_workflow', 'department', 'group', 'projects', 'employee', 'levels']
    search_fields = ['workflow_name', 'department', 'group', 'employee']
    list_filter = ['manage_workflow', 'department', 'group', 'levels']

class AddnewholidayAdmin(admin.ModelAdmin):
    list_display = ('name','calendar'
        )
    form = AddnewholidayForm

admin.site.register(Addnewholiday, AddnewholidayAdmin)


# Define the EmployeeAdmin class
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'department', 'email')  # Customize this as needed
    form = EmployeeForm  # Use the custom form

# Register the Employee model with the EmployeeAdmin class
admin.site.register(Employee, EmployeeAdmin)

# Define the ProjectsAdmin class
class ProjectsAdmin(admin.ModelAdmin):
    list_display = (
        'project_id', 'photograph', 'project_name', 'department', 'group', 'employee', 'shift', 'supervisor',
        'description', 'public_holiday', 'rest_day'
    )
    form = ProjectsForm  # Use the custom form

# Register the Projects model with the ProjectsAdmin class
admin.site.register(Projects, ProjectsAdmin)

class WorkexperienceAdmin(admin.ModelAdmin):
    list_display = ('designation','department','from_date','to_date','employment_type','salary',
        'attachment_doc','remarks','company_name','designations','date_of_joining','date_of_leaving'
     )
    form =WorkexperienceForm
admin.site.register(Workexperience, WorkexperienceAdmin) 

class EducationAdmin(admin.ModelAdmin):
    list_display = ('qualification','institute','type','start_date','end_date','description'
        
     )
    form =EducationForm
admin.site.register(Education, EducationAdmin) 


class DocsAdmin(admin.ModelAdmin):
    list_display = ('type_name','photograph','id','date_of_issue','date_of_expiry'
        
     )
    form =DocsForm
admin.site.register(Docs, DocsAdmin)

class ClaimsuploadAdmin(admin.ModelAdmin):
    list_display = ('upload_document',)
    form = ClaimsuploadForm

admin.site.register(Claimsupload, ClaimsuploadAdmin)

class ImporttimesheetAdmin(admin.ModelAdmin):
    list_display = ('upload_document',)
    form = ImporttimesheetForm

admin.site.register(Importtimesheet, ImporttimesheetAdmin)

class TimesheetaddAdmin(admin.ModelAdmin):
    list_display = ('project','shift','employee','date','in_time','out_time')
    form = TimesheetaddForm

admin.site.register(Timesheetadd, TimesheetaddAdmin)

@admin.register(Biometriclogrecords)
class BiometriclogrecordsAdmin(admin.ModelAdmin):
    list_display = ('employee', 'month', 'year', 'payroll_type')
    list_filter = ('year', 'month', 'payroll_type')
    search_fields = ('employee__first_name', 'employee__last_name', 'payroll_type')
    ordering = ('year', 'month')

class AddnewshiftsAdmin(admin.ModelAdmin):
    # Display the fields in the admin list view
    list_display = (
        'Shift_Name', 'colored_name', 'In_Time', 'Out_Time', 
        'Earliest_Clock_In_Time', 'Last_Clock_Out_Time', 
        'Auto_Clock_Out', 'Roster_Settings', 'Amount_Per_Min'
    )
    
    # Add search functionality to find shifts by name or supervisor name
    search_fields = ('Shift_Name', 'Supervisor_Name', 'Poster_Code')

    # Add filters to filter the shifts based on these fields
    list_filter = ('Auto_Clock_Out', 'Roster_Settings')

    # Use readonly fields to display computed fields like colored_name
    readonly_fields = ('colored_name',)
    
    # Customize how the model is displayed on the detail page in the admin site
    fieldsets = (
        ('Shift Information', {
            'fields': ('Shift_Id', 'Shift_Name', 'Pick_Color', 'colored_name')
        }),
        ('Time Settings', {
            'fields': ('In_Time', 'Out_Time', 'Earliest_Clock_In_Time', 'Last_Clock_Out_Time', 'Late_In_From')
        }),
        ('Break and OT Settings', {
            'fields': ('Break_Time_Normal_Hours', 'OT_Break_Time_Normal_Hours', 'OT_To_Only_Start_After', 'OT_Break_Takes_Effect_After')
        }),
        ('Pay and Fine', {
            'fields': ('Basic_Pay', 'Custom_Fine', 'Amount_Per_Min', 'Fixed')
        }),
        ('Roster Settings', {
            'fields': ('Auto_Clock_Out', 'Roster_Settings', 'Supervisor_Name')
        }),
    )

    # Optional: Add ordering by a specific field, e.g., Shift Name
    ordering = ('Shift_Name',)

admin.site.register(Addnewshifts, AddnewshiftsAdmin)

class CostcenterAdmin(admin.ModelAdmin):
    list_display = (
        'costcenter', 'description', 'percentage'
    )
    form = CostcenterForm 

admin.site.register(Costcenter, CostcenterAdmin)

class AddnewbankAdmin(admin.ModelAdmin):
    list_display = (
        'bank_name','branch_code','bank_acc_number','account_name','organization_id'
    )
    form = AddnewbankForm 

admin.site.register(Addnewbank, AddnewbankAdmin)

class BankdetailsAdmin(admin.ModelAdmin):
    list_display = (
        'payment_mode','employee_bank','bank_code','account_no','bank_branch_code','bank_b1',
        'bank','bank_info_details',
        'check_banked','chip_level_bank','covid_vaccine','discovery'
    )
    form = BankdetailsForm 

admin.site.register(Bankdetails, BankdetailsAdmin)

class InventoryAdmin(admin.ModelAdmin):
    list_display = (
        'item_name', 'quantity', 'file_attachment', 'description', 'date_of_issue', 'date_of_collection'
    )
    form = InventoryForm  

admin.site.register(Inventory, InventoryAdmin)

class TrainingAdmin(admin.ModelAdmin):
    list_display = (
        'certification', 'grade', 'file_attachment', 'effective_date', 'projected_date', 'status'
    )
    form = TrainingForm  

admin.site.register(Training, TrainingAdmin)


class ExpensesAdmin(admin.ModelAdmin):
    list_display = (
        'amount', 'issued_date', 'description'
    )
    form = ExpensesForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Expenses, ExpensesAdmin)


# Define the GroupsAdmin class
class GroupsAdmin(admin.ModelAdmin):
    list_display = (
        'group_id', 'photograph', 'group_name', 'department', 'projects', 'employees'
    )
    form = GroupsForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Groups, GroupsAdmin)

class LeaveapplicationAdmin(admin.ModelAdmin):
    list_display = (
        'employee','leave_type', 'from_date', 'to_date', 'sessions','no_of_days_applying','remarks','upload_document'
    )
    form = LeaveapplicationForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Leaveapplication, LeaveapplicationAdmin)

class LeavebulkuploadAdmin(admin.ModelAdmin):
    form = LeavebulkuploadForm
    list_display = ('template', 'format', 'upload_document')

admin.site.register(Leavebulkupload, LeavebulkuploadAdmin)

class OffinlieuallocationAdmin(admin.ModelAdmin):
    form = OffinlieuallocationForm
    list_display = ('template', 'format', 'upload_document')

admin.site.register(Offinlieuallocation, OffinlieuallocationAdmin)

class AddnewdepartmentAdmin(admin.ModelAdmin):
    list_display = ('photograph', 'department_name', 'employee_name')

admin.site.register(Addnewdepartment, AddnewdepartmentAdmin)



class AddnewleavetypeAdmin(admin.ModelAdmin):
    list_display = (
        'leave_type', 'leave_code', 'apply_in_days', 'apply_in_hours', 'apply_in_minutes', 
        'off_in_lieu', 'full_day', 'half_day', 'employee_remarks', 'upload_document', 
        'approvals_remarks', 'entitled_in_probation', 'not_entitled_in_probation', 'note', 'yes', 'no'
    )
    form = AddnewleavetypeForm  # Use the custom form

admin.site.register(Addnewleavetype, AddnewleavetypeAdmin)

class AddnewemployeeAdmin(admin.ModelAdmin):
    list_display = (
        'first_name', 'last_name', 'alias_name', 'preferred_name', 'gender', 'marital_status', 
        'date_of_birth', 'nationality', 'religion', 'race', 'blood_group', 'place_of_birth', 
        'identification_type', 'ic_no', 'block_number', 'house_number', 'street_number', 
        'country', 'postal_code', 'mobile_number', 'emergency_contact_person', 'relationship', 
        'emergency_contact', 'overseas_address', 'personal_email_address', 'photograph', 'email', 
        'user_security', 'custom_field_add', 'email_outlook_access', 'first_name_for_email_creation', 
        'last_name_for_email_creation', 'may_day', 'name_of_vaccine_1st_dose', 'new_year_event', 
        'physical_last_day', 'physical_last_working_day', 'sports', 'surname', 'test_s', 'employee_id', 
        'joining_date', 'employment_type', 'probation_period', 'confirmation_date', 'departments', 
        'designation', 'groups', 'supervisor_name', 'appraisal_supervisor1', 'appraisal_supervisor2', 
        'academic_qualification', 'skill_set', 'working_hours_per_month', 'working_hours_per_day', 
        'working_days_per_week', 'no_of_work_days_per_week', 'working_hours_per_day_breakdown', 
        'payroll_frequency', 'salary_type', 'basic_pay', 'payslip_language', 'leave_workflow', 
        'leave_code', 'leave_type_entitlement', 'claim_workflow', 'claim_types', 
        'length_of_notice_period', 'cpf_entitled', 'cpf_file_type', 'contribute_sdl', 
        'sdl_breakdown', 'fund_donation', 'clock_in_out_on_web', 'clock_in_out_on_mobile', 
        'remarks', 'job_grade', 'pin_number', 'geofencing_postal_code', 'abc', 'custom_field1', 
        'dd', 'email_for_supervisor', 'family_relationship', 'job_type', 'job_type_list', 
        'job_type1', 'job_type2', 'job_type3', 'sample', 'service_date_dd_mm_yyyy', 'testing_1'
    )
    form = AddnewemployeeForm  # Use the custom form

# Register the Addnewemployee model with the AddnewemployeeAdmin class
admin.site.register(Addnewemployee, AddnewemployeeAdmin)

class ClaimapplicationAdmin(admin.ModelAdmin):
    list_display = (
        'employee_name','claim_type','from_date','to_date','project_name','custom_claim','receipt_id','attachment1','attachment2',
        'description','currency','exchange_rate','quantity','amount','gst'

    )
    form = ClaimapplicationForm  # Use the custom form

# Register the Groups model with the GroupsAdmin class
admin.site.register(Claimapplication, ClaimapplicationAdmin)


